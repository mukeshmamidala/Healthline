function add (){
    window.alert('Hai');
}
function change(){
    document.getElementById("h22").style.color = "blue";
    document.getElementById("h22").style.fontFamily = "Arial";
    document.getElementById("h22").style.fontSize = "larger";
}