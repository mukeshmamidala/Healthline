module.exports = {

 add: function(){
 console.log('Hai there');
 }
};